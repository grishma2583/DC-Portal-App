package com.example.afinal;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<listholder> {

    private Context context;
    private ArrayList<name> list;
    private String className;
    private String searchSapId;

    public MyAdapter(Context context, ArrayList<name> list, String className, String searchSapId) {
        this.context = context;
        this.list = (list != null) ? list : new ArrayList<>(); // prevent null list
        this.className = className;
        this.searchSapId = searchSapId;
    }

    @NonNull
    @Override
    public listholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.student_info, parent, false);
        return new listholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull listholder holder, int position) {
        name student = list.get(position);
        holder.nametv.setText(student.getName());
        holder.sapidtv.setText(student.getSap());

        // Highlight if matches SAP ID
        if (searchSapId != null && student.getSap().equals(searchSapId)) {
            holder.itemView.setBackgroundColor(context.getResources().getColor(R.color.yellow));
        } else {
            holder.itemView.setBackgroundColor(context.getResources().getColor(android.R.color.white));
        }

        holder.itemView.setOnClickListener(v -> {
            if (student.getKey() != null) {
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("studentKey", student.getKey());
                intent.putExtra("className", className);
                context.startActivity(intent);
            } else {
                Toast.makeText(context, "Student key is missing", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
