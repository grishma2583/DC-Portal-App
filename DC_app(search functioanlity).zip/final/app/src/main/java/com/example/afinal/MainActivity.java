package com.example.afinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.afinal.databinding.ActivityMainBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    ImageView imageView1, imageView2, imageView3, imageView4, imageView5;
    ImageView cardA_img2, cardB_img2, cardC_img2, cardD_img2, cardE_img2;

    ImageView cardA_img3, cardB_img3, cardC_img3, cardD_img3, cardE_img3;
    EditText searchEditText;

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.grey));
        }

        binding.fab.setOnClickListener(view -> {
            Intent in = new Intent(MainActivity.this, addstd.class);
            startActivity(in);
        });

        // Search Bar Logic
        searchEditText = findViewById(R.id.searchEditText);
        searchEditText.setOnEditorActionListener((v, actionId, event) -> {
            String sapId = v.getText().toString().trim();
            if (!sapId.isEmpty()) {
                searchStudentBySAP(sapId);
            } else {
                Toast.makeText(MainActivity.this, "Please enter SAP ID", Toast.LENGTH_SHORT).show();
            }
            return true;
        });

        String messageA = "Misconducts:-\n" +
                "A - 1  Possession / Consumption / Transportation of Objectionable Material (Includes making / threatening fellow students to bring the material inside Campus)\n" +
                "A - 2  Any act by the student which management deems fit for Rustication / Expulsion\n" +
                "A - 3  Ragging\n\n" +
                "Consequences :-\n" +
                "All cases mentioned in Class - A will be referred through Campus Discipline Committee to the Office of the Registrar, SVKM’s NMIMS, Mumbai, where the Campus Discipline Committee deems fit/necessary.";

        String messageB = "Misconducts:-\n\n" +
                "B - 1  Possession / Consumption / Transportation of Alcohol (Includes making / threatening fellow students to bring the alcohol material inside the Campus)\n" +
                "B - 2  Any complaint of major misconduct received from inside or outside the Campus.\n" +
                "B - 3  Serious physical fight among students or with any staff member at Campus or outside person.\n\n" +
                "Consequences:-\n" +
                "1st Time: He / She found guilty for breaking of the subject rule for the first time shall be liable to academic and hostel (Campus) suspension for 10 Days. On rejoining the Campus, He / She has to submit the undertaking of parents on stamp paper of Rs. 100/-.\n\n" +
                "2nd Time: He / She found guilty for breaking of the subject rule for the second time shall be liable to suspension from academic and hostel (Campus) for 20 Days. On rejoining the Campus, He / She has to submit the undertaking of parents on stamp paper of Rs. 100/-.\n\n" +
                "3rd Time: He / She found guilty for breaking of the subject rule for the third time shall be liable to suspension from academic and hostel (Campus) for 30 days.\n\n" +
                "In all cases ONE MONTH yoga Session and 10 Counselling Sessions are compulsory to attend.";

        String messageC = "Misconducts:-\n" +
                "C – 1 Possession / Consumption / Transportation of Smoking material\n" +
                "C – 2 Damage to Campus property\n" +
                "C – 3 Pornographic literature as well as pen drive / CD / any other storage (Hard & Soft copies)\n" +
                "C – 4 Any misbehavior, fight, unlawful activities during placement tour and inside campus\n" +
                "C – 5 Forgery of signatures of authority / producing false documents / giving false information pertaining to hostel and non-academic rules\n" +
                "C – 6 Stealing cash or any other item\n\n" +

                "Consequences:-\n" +
                "1st Time: (any misconduct in class C)\n" +
                "Expulsion from academic and hostel (Campus) for 07 Days. On re-joining the Campus, He / She has to submit the undertaking of parents on stamp paper of Rs.100/-. " +
                "Ban on short leave, Shirpur Out-Pass for a period of 90 days.\n\n" +

                "2nd Time: (any misconduct in class C)\n" +
                "Expulsion from academic and hostel (Campus) for 15 days. On re-joining the Campus, He / She has to submit the undertaking of parents on stamp paper of Rs.100/-. " +
                "Ban on short leave, Shirpur Out-Pass for a period of 180 days.\n\n" +

                "3rd Time: (any misconduct in class C)\n" +
                "Suspension from academic and hostel (Campus) for One Semester or 20 days whichever is higher. On re-joining the Campus, He / She has to submit the undertaking of parents on stamp paper of Rs.100/-. " +
                "Ban on short leave, Shirpur Out-Pass for a period of 1 year (365 days).\n\n" +

                "In case of any misbehavior during placement tour, disqualification for further placement assistance.\n\n" +
                "In all cases 20 yoga Sessions and 10 Counselling Sessions are compulsory to attend.";

        String messageD = "Misconducts:\n" +
                "• D - 1: Late reporting after vacation\n" +
                "• D - 2: Shouting slogans and raising voice in a group\n" +
                "• D - 3: Using bad words / gestures with fellow students / staff / faculty / security / HK\n" +
                "• D - 4: Any complaint of minor misconduct received from outside the campus\n" +
                "• D - 5: Found in an indecent position / objectionable pose with a fellow student\n\n" +
                "Consequences:\n" +
                "• Intimation to parents\n" +
                "• And 03 days’ academic suspension with pre-marked absence in SAP\n" +
                "  (i.e., student will attend classes but will lose attendance)\n" +
                "• And Ban on short leave, Shirpur out-pass for a period of 20 days\n" +
                "• In case of property damage, the cost of property repairing / replacement would be recovered\n" +
                "• In all cases 10 yoga sessions and 10 counselling sessions are compulsory to attend";

        String messageE = "Misconducts:\n" +
                "E - 1: Use of Electrical appliances other than Laptop and Cell phone and for medical reasons without prior approval\n" +
                "E - 2: Indiscipline in Theatre / Auditorium / Dining hall / Grounds / Play Courts / Gym / Sports area / Swimming pool or any other area in Campus\n" +
                "E - 3: Entry of non-resident student in hostel room. (Action against both i.e. hostel resident and non-resident)\n" +
                "\n"+
                "Consequences:\n" +
                "1st Time (any misconduct in class E):\n" +
                "A) 05 days’ academic suspension with pre-marked absence in SAP (i.e., student will attend the classes but will lose attendance)\n" +
                "B) 15 days’ compulsory yoga classes\n" +
                "C) Ban on short leave, Shirpur out-pass for the period of one month.\n" +
                "In case of non-resident of hostel fine will be imposed of Rs. 5,000/-\n" +"\n"+
                "2nd Time (any misconduct in class E):\n" +
                "D) 10 days’ academic suspension with pre-marked absence in SAP (i.e., student will attend the classes but will lose attendance)\n" +
                "E) 30 days’ compulsory yoga classes\n" +
                "F) Ban on short leave, Shirpur out-pass for the period of three months\n" +
                "In case of non-resident student, fine of Rs. 2,000/- will be imposed";


        // Cards setup
        imageView1 = findViewById(R.id.cardA_img1);
        imageView2 = findViewById(R.id.cardB_img1);
        imageView3 = findViewById(R.id.cardC_img1);
        imageView4 = findViewById(R.id.cardD_img1);
        imageView5 = findViewById(R.id.cardE_img1);

        cardA_img2 = findViewById(R.id.cardA_img2);
        cardB_img2 = findViewById(R.id.cardB_img2);
        cardC_img2 = findViewById(R.id.cardC_img2);
        cardD_img2 = findViewById(R.id.cardD_img2);
        cardE_img2 = findViewById(R.id.cardE_img2);

        cardA_img3 = findViewById(R.id.cardA_img3);
        cardB_img3 = findViewById(R.id.cardB_img3);
        cardC_img3 = findViewById(R.id.cardC_img3);
        cardD_img3 = findViewById(R.id.cardD_img3);
        cardE_img3 = findViewById(R.id.cardE_img3);


        // Card click listeners
        cardA_img2.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, stdlist.class)));
        cardB_img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ClassBActivity.class);
                startActivity(intent);
            }
        });
        cardC_img2.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ClassC.class)));
        cardD_img2.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ClassD.class)));
        cardE_img2.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ClassE.class)));

        cardA_img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Class A")
                        .setMessage(messageA)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
        cardB_img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Class B")
                        .setMessage(messageB)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
        cardC_img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Class C")
                        .setMessage(messageC)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
        cardD_img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Class D")
                        .setMessage(messageD)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
        cardE_img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Class E")
                        .setMessage(messageE)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });


    }

    private void searchStudentBySAP(String sapId) {
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference().child("Students");
        String[] classList = {"Class A", "Class B", "Class C", "Class D", "Class E"};
        boolean[] found = {false};

        for (String className : classList) {
            dbRef.child(className).orderByChild("sap").equalTo(sapId)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists() && !found[0]) {
                                found[0] = true;

                                Intent intent = null;
                                switch (className) {
                                    case "Class A":
                                        intent = new Intent(MainActivity.this, stdlist.class);
                                        break;
                                    case "Class B":
                                        intent = new Intent(MainActivity.this, ClassBActivity.class);
                                        break;
                                    case "Class C":
                                        intent = new Intent(MainActivity.this, ClassC.class);
                                        break;
                                    case "Class D":
                                        intent = new Intent(MainActivity.this, ClassD.class);
                                        break;
                                    case "Class E":
                                        intent = new Intent(MainActivity.this, ClassE.class);
                                        break;
                                }

                                if (intent != null) {
                                    intent.putExtra("searched_sap", sapId);
                                    startActivity(intent);
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(MainActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        // Handling logout menu item
        if (id == R.id.menu_logout) {
            showLogoutDialog();
            return true;
        }

        // Handling feedback menu item
        if (id == R.id.menu_feedback) {
            // Create an Intent to open the feedback link in a browser
            String feedbackUrl = "https://docs.google.com/forms/d/e/1FAIpQLScpTLD6tITl73VHgk4CP78vSFJL592joelz_8TUaY07nHwVow/viewform?usp=header "; // Replace with your feedback URL
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(feedbackUrl));
            startActivity(intent); // Start the activity to open the URL
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    Toast.makeText(MainActivity.this, "Logged out!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, login.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .setCancelable(true)
                .show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        return true;
    }
}
