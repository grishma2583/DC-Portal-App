package com.example.afinal;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class listholder extends RecyclerView.ViewHolder {
    TextView nametv, sapidtv;

    public listholder(@NonNull View itemView) {
        super(itemView);
        nametv = itemView.findViewById(R.id.textname);
        sapidtv = itemView.findViewById(R.id.textsap);
    }
}
