package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {

    EditText text1, text2;
    Button button;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        text1 = findViewById(R.id.editTextText); // Email
        text2 = findViewById(R.id.editTextTextPassword); // Password
        button = findViewById(R.id.button);
        mAuth = FirebaseAuth.getInstance();

        button.setOnClickListener(v -> {
            String email = text1.getText().toString().trim();
            String password = text2.getText().toString().trim();

            if (TextUtils.isEmpty(email)) {
                text1.setError("Email is required");
                return;
            }

            if (TextUtils.isEmpty(password)) {
                text2.setError("Password is required");
                return;
            }

            if (password.length() < 6) {
                text2.setError("Password must be at least 6 characters");
                return;
            }

            // Firebase login
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(login.this, "Login successful", Toast.LENGTH_SHORT).show();
                            // Redirect to another activity
                            startActivity(new Intent(getApplicationContext(), MainActivity.class)); // change to your destination activity
                            finish();
                        } else {
                            Toast.makeText(login.this, "Login failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        });
    }
}
