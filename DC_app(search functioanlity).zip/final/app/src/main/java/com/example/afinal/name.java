package com.example.afinal;

public class name {
    private String key;
    private String name;
    private String sap;
    private String roll;
    private String course;
    private String branch;
    private String year;
    private String reason;
    private String className; // Changed from "Class" to "className"

    // ✅ New field for highlighting
    private boolean highlighted = false;

    public name() {
        // Required empty constructor for Firebase
    }

    public name(String name, String sap, String key, String roll, String branch,
                String course, String year, String reason, String className) {
        this.name = name;
        this.sap = sap;
        this.key = key;
        this.roll = roll;
        this.branch = branch;
        this.course = course;
        this.year = year;
        this.reason = reason;
        this.className = className;
    }

    // Getters and Setters
    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSap() { return sap; }
    public void setSap(String sap) { this.sap = sap; }

    public String getRoll() { return roll; }
    public void setRoll(String roll) { this.roll = roll; }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    public String getBranch() { return branch; }
    public void setBranch(String branch) { this.branch = branch; }

    public String getYear() { return year; }
    public void setYear(String year) { this.year = year; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }

    // ✅ New getter and setter for highlight state
    public boolean isHighlighted() {
        return highlighted;
    }

    public void setHighlighted(boolean highlighted) {
        this.highlighted = highlighted;
    }
}
