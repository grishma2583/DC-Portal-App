package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class update extends AppCompatActivity {

    EditText nameEditText, sapEditText, rollEditText, reasonEditText;
    Spinner classSpinner;
    RadioGroup courseRadioGroup, yearRadioGroup, branchRadioGroup;
    Button saveButton, resetButton;

    String studentKey, className;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        // Initialize views
        nameEditText = findViewById(R.id.editname);
        sapEditText = findViewById(R.id.editsap);
        rollEditText = findViewById(R.id.editroll);
        reasonEditText = findViewById(R.id.editreason);

        classSpinner = findViewById(R.id.spinnerclass);
        courseRadioGroup = findViewById(R.id.radioGroup3);
        yearRadioGroup = findViewById(R.id.radioGroup2);
        branchRadioGroup = findViewById(R.id.radioGroup1);
        saveButton = findViewById(R.id.button2);
        resetButton = findViewById(R.id.button3);

        // Spinner setup
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.dc_class, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        classSpinner.setAdapter(adapter);

        // Get data from Intent
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String sap = intent.getStringExtra("sap");
        String roll = intent.getStringExtra("roll");
        String reason = intent.getStringExtra("reason");
        String studentClass = intent.getStringExtra("class");
        String course = intent.getStringExtra("course");
        String year = intent.getStringExtra("year");
        String branch = intent.getStringExtra("branch");
        studentKey = intent.getStringExtra("studentKey");
        className = intent.getStringExtra("className"); // original class

        // Set existing data
        nameEditText.setText(name);
        sapEditText.setText(sap);
        rollEditText.setText(roll);
        reasonEditText.setText(reason);

        if (studentClass != null) {
            int spinnerPosition = adapter.getPosition(studentClass);
            classSpinner.setSelection(spinnerPosition);
        }

        setRadioButton(courseRadioGroup, course);
        setRadioButton(yearRadioGroup, year);
        setRadioButton(branchRadioGroup, branch);

        // Save button listener
        saveButton.setOnClickListener(v -> {
            String updatedName = nameEditText.getText().toString();
            String updatedSap = sapEditText.getText().toString();
            String updatedRoll = rollEditText.getText().toString();
            String updatedReason = reasonEditText.getText().toString();
            String updatedClass = classSpinner.getSelectedItem().toString();

            String updatedCourse = getSelectedRadio(courseRadioGroup);
            String updatedYear = getSelectedRadio(yearRadioGroup);
            String updatedBranch = getSelectedRadio(branchRadioGroup);

            // New Firebase reference (to selected class)
            DatabaseReference newReference = FirebaseDatabase.getInstance()
                    .getReference("Students")
                    .child(updatedClass)
                    .child(studentKey);

            // Data to update
            HashMap<String, Object> updates = new HashMap<>();
            updates.put("name", updatedName);
            updates.put("sap", updatedSap);
            updates.put("roll", updatedRoll);
            updates.put("reason", updatedReason);
            updates.put("Class", updatedClass);
            updates.put("course", updatedCourse);
            updates.put("year", updatedYear);
            updates.put("branch", updatedBranch);

            // Save data in new location
            newReference.updateChildren(updates)
                    .addOnSuccessListener(unused -> {
                        // If class changed, delete from old class
                        if (!updatedClass.equals(className)) {
                            DatabaseReference oldReference = FirebaseDatabase.getInstance()
                                    .getReference("Students")
                                    .child(className)
                                    .child(studentKey);
                            oldReference.removeValue();
                        }

                        Toast.makeText(update.this, "Data updated successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(update.this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                    );
        });

        // Reset button logic (optional)
        resetButton.setOnClickListener(v -> {
            nameEditText.setText("");
            sapEditText.setText("");
            rollEditText.setText("");
            reasonEditText.setText("");
            classSpinner.setSelection(0);
            courseRadioGroup.clearCheck();
            yearRadioGroup.clearCheck();
            branchRadioGroup.clearCheck();
        });
    }

    private void setRadioButton(RadioGroup group, String value) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View view = group.getChildAt(i);
            if (view instanceof RadioButton) {
                RadioButton radio = (RadioButton) view;
                if (radio.getText().toString().equalsIgnoreCase(value)) {
                    radio.setChecked(true);
                    break;
                }
            }
        }
    }

    private String getSelectedRadio(RadioGroup group) {
        int selectedId = group.getCheckedRadioButtonId();
        RadioButton selectedRadio = findViewById(selectedId);
        return selectedRadio != null ? selectedRadio.getText().toString() : "";
    }
}
