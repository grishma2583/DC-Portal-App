package com.example.afinal;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.HashMap;

public class addstd extends AppCompatActivity {
    Spinner spinner;
    EditText stdname, sapid, stdroll, reason;
    RadioGroup course, year, branch;
    RadioGroup courseGroup, yearGroup, branchGroup;

    Button submit, reset;
    String selectedRadioText, selectedRadioText1, selectedRadioText2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addstd);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        courseGroup = findViewById(R.id.radioGroup2);
        yearGroup = findViewById(R.id.radioGroup3);
        branchGroup = findViewById(R.id.radioGroup1);

        stdname = findViewById(R.id.editTextText2);
        sapid = findViewById(R.id.editTextText3);
        stdroll = findViewById(R.id.editTextText4);
        reason = findViewById(R.id.editTextText5);
        course = findViewById(R.id.radioGroup2);
        year = findViewById(R.id.radioGroup3);
        branch = findViewById(R.id.radioGroup1);
        submit = findViewById(R.id.button2);
        reset = findViewById(R.id.button3);
        spinner = findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.dc_class,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedClass = parent.getItemAtPosition(position).toString();
                Toast.makeText(addstd.this, "Selected: " + selectedClass, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = stdname.getText().toString().trim();
                String sap = sapid.getText().toString().trim();
                String roll = stdroll.getText().toString().trim();
                String reasonText = reason.getText().toString().trim();
                String selectedSpinnerItem = spinner.getSelectedItem().toString();

                int selectedRadioId = year.getCheckedRadioButtonId();
                int selectedRadioId1 = branch.getCheckedRadioButtonId();
                int selectedRadioId2 = course.getCheckedRadioButtonId();

                if (selectedSpinnerItem.equals("Select an option")) {
                    Toast.makeText(addstd.this, "Please select a valid option from the spinner", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (selectedRadioId != -1) {
                    RadioButton selectedRadioButton = findViewById(selectedRadioId);
                    selectedRadioText = selectedRadioButton.getText().toString();
                } else {
                    Toast.makeText(addstd.this, "Please select Year", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (selectedRadioId1 != -1) {
                    RadioButton selectedRadioButton1 = findViewById(selectedRadioId1);
                    selectedRadioText1 = selectedRadioButton1.getText().toString();
                } else {
                    Toast.makeText(addstd.this, "Please select Branch", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (selectedRadioId2 != -1) {
                    RadioButton selectedRadioButton2 = findViewById(selectedRadioId2);
                    selectedRadioText2 = selectedRadioButton2.getText().toString();
                } else {
                    Toast.makeText(addstd.this, "Please select Course", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (name.isEmpty() || sap.isEmpty() || roll.isEmpty() || reasonText.isEmpty()) {
                    Toast.makeText(addstd.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!sap.matches("\\d{11}")) {
                    Toast.makeText(addstd.this, "SAP ID must be exactly 11 digits", Toast.LENGTH_SHORT).show();
                    return;
                }

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference stdref = database.getReference("Students").child(selectedSpinnerItem);

                stdref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        boolean exists = false;
                        for (DataSnapshot child : snapshot.getChildren()) {
                            String existingSap = child.child("sap").getValue(String.class);
                            if (sap.equals(existingSap)) {
                                exists = true;
                                break;
                            }
                        }

                        if (exists) {
                            Toast.makeText(addstd.this, "Student with this SAP ID already exists", Toast.LENGTH_SHORT).show();
                        } else {
                            addItemToDb(name, sap, roll, reasonText, selectedSpinnerItem, selectedRadioText, selectedRadioText1, selectedRadioText2);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(addstd.this, "Database error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stdname.setText("");
                sapid.setText("");
                stdroll.setText("");
                reason.setText("");
                courseGroup.clearCheck();
                yearGroup.clearCheck();
                branchGroup.clearCheck();
                spinner.setSelection(0);
                Toast.makeText(addstd.this, "Form reset", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addItemToDb(String name, String sap, String roll, String reasonText,
                             String selectedSpinnerItem, String year, String branch, String course) {

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference stdref = database.getReference("Students").child(selectedSpinnerItem);
        String key = stdref.push().getKey();

        HashMap<String, Object> allData = new HashMap<>();
        allData.put("name", name);
        allData.put("sap", sap);
        allData.put("roll", roll);
        allData.put("reason", reasonText);
        allData.put("className", selectedSpinnerItem); // ✅ Fixed key name
        allData.put("year", year);
        allData.put("branch", branch);
        allData.put("course", course);
        allData.put("key", key);

        stdref.child(key).setValue(allData).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(addstd.this, "Data added successfully", Toast.LENGTH_SHORT).show();
                    stdname.setText("");
                    sapid.setText("");
                    stdroll.setText("");
                    reason.setText("");
                    courseGroup.clearCheck();
                    yearGroup.clearCheck();
                    branchGroup.clearCheck();
                    spinner.setSelection(0);
                } else {
                    Toast.makeText(addstd.this, "Failed to add data", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
