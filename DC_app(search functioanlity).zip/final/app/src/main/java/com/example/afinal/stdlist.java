package com.example.afinal;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class stdlist extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<name> list;
    MyAdapter adapter;
    DatabaseReference dbRef;
    String searchedSap = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stdlist);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        searchedSap = getIntent().getStringExtra("searched_sap");

        adapter = new MyAdapter(this, list, "Class A", searchedSap); // ✅ Use the same constructor as ClassBActivity
        recyclerView.setAdapter(adapter);

        dbRef = FirebaseDatabase.getInstance().getReference("Students").child("Class A"); // Reference to Class A in Firebase

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    name student = dataSnapshot.getValue(name.class);
                    if (student != null) {
                        student.setKey(dataSnapshot.getKey());

                        // Optional: mark highlight here, or let Adapter do it
                        if (searchedSap != null && searchedSap.equals(student.getSap())) {
                            student.setHighlighted(true);
                        }

                        list.add(student);
                    }
                }
                adapter.notifyDataSetChanged();

                // Optional: auto-scroll if needed
                if (searchedSap != null) {
                    scrollToHighlighted();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error
            }
        });
    }

    private void scrollToHighlighted() {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).isHighlighted()) {
                recyclerView.scrollToPosition(i);
                break;
            }
        }
    }
}
