package com.example.afinal;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ClassD extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<name> list;
    MyAdapter adapter;
    DatabaseReference databaseReference;
    String searchedSap = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_c); // Reuse the same layout as Class C

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();

        // Get the searched SAP ID (if any) passed from the search screen or previous activity
        searchedSap = getIntent().getStringExtra("searched_sap");

        // Pass the searched SAP ID to the adapter constructor
        adapter = new MyAdapter(this, list, "Class D", searchedSap);
        recyclerView.setAdapter(adapter);

        // Reference to the Firebase database for Class D
        databaseReference = FirebaseDatabase.getInstance().getReference("Students").child("Class D");

        // Listen for data changes in the Firebase database
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear(); // Clear the list to avoid duplications

                // Loop through each student in the database and add to the list
                for (DataSnapshot studentSnapshot : snapshot.getChildren()) {
                    name student = studentSnapshot.getValue(name.class);
                    if (student != null) {
                        student.setKey(studentSnapshot.getKey()); // Set the unique student key
                        list.add(student);
                    }
                }

                adapter.notifyDataSetChanged(); // Notify adapter that data has changed

                // If a searched SAP ID is available, highlight the student and scroll to them
                if (searchedSap != null && !searchedSap.isEmpty()) {
                    highlightStudentBySap(searchedSap); // Method to highlight and scroll
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ClassD.this, "Failed to load data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to highlight the student by SAP ID and auto-scroll to them
    public void highlightStudentBySap(String sapId) {
        int highlightedPosition = -1;

        // Iterate over the list and find the student with the matching SAP ID
        for (int i = 0; i < list.size(); i++) {
            name student = list.get(i);
            boolean isMatch = student.getSap().equals(sapId);
            student.setHighlighted(isMatch); // Mark student as highlighted
            if (isMatch) {
                highlightedPosition = i; // Save the position of the highlighted student
            }
        }

        adapter.notifyDataSetChanged(); // Notify adapter to update the view

        // Scroll to the position of the highlighted student
        if (highlightedPosition != -1) {
            recyclerView.scrollToPosition(highlightedPosition);
        }
    }
}
