package com.example.afinal;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DetailActivity extends AppCompatActivity {

    TextView nameTv, sapTv, rollTv, branchTv, yearTv, courseTv, reasonTv, classTv;
    DatabaseReference databaseReference;
    String studentKey, className;
    Button updateButton, deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Initialize TextViews
        nameTv = findViewById(R.id.nameText);
        sapTv = findViewById(R.id.sapText);
        rollTv = findViewById(R.id.rollText);
        branchTv = findViewById(R.id.branchText);
        yearTv = findViewById(R.id.yearText);
        courseTv = findViewById(R.id.courseText);
        reasonTv = findViewById(R.id.reasonText);
        classTv = findViewById(R.id.classText);

        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);

        // Get the student key and class name from Intent
        studentKey = getIntent().getStringExtra("studentKey");
        className = getIntent().getStringExtra("className");

        if (studentKey == null || className == null) {
            Toast.makeText(this, "Missing data", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Reference to the student's data in Firebase
        databaseReference = FirebaseDatabase.getInstance()
                .getReference("Students")
                .child(className)
                .child(studentKey);

        // Fetch the student data
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    String sap = snapshot.child("sap").getValue(String.class);
                    String roll = snapshot.child("roll").getValue(String.class);
                    String branch = snapshot.child("branch").getValue(String.class);
                    String year = snapshot.child("year").getValue(String.class);
                    String course = snapshot.child("course").getValue(String.class);
                    String reason = snapshot.child("reason").getValue(String.class);
                    String classNameValue = snapshot.child("Class").getValue(String.class);

                    nameTv.setText(name);
                    sapTv.setText(sap);
                    rollTv.setText(roll);
                    branchTv.setText(branch);
                    yearTv.setText(year);
                    courseTv.setText(course);
                    reasonTv.setText(reason);
                    classTv.setText(classNameValue);

                    // UPDATE BUTTON
                    updateButton.setOnClickListener(v -> {
                        Intent intent = new Intent(DetailActivity.this, update.class);
                        intent.putExtra("studentKey", studentKey);
                        intent.putExtra("className", className);
                        intent.putExtra("name", name);
                        intent.putExtra("sap", sap);
                        intent.putExtra("roll", roll);
                        intent.putExtra("branch", branch);
                        intent.putExtra("year", year);
                        intent.putExtra("course", course);
                        intent.putExtra("reason", reason);
                        intent.putExtra("Class", classNameValue);
                        startActivity(intent);
                    });

                    // DELETE BUTTON
                    deleteButton.setOnClickListener(v -> {
                        new AlertDialog.Builder(DetailActivity.this)
                                .setTitle("Delete Student")
                                .setMessage("Are you sure you want to delete this student?")
                                .setPositiveButton("Yes", (dialog, which) -> {
                                    databaseReference.removeValue().addOnSuccessListener(unused -> {
                                        Toast.makeText(DetailActivity.this, "Student deleted successfully", Toast.LENGTH_SHORT).show();
                                        finish(); // Go back after deletion
                                    }).addOnFailureListener(e -> {
                                        Toast.makeText(DetailActivity.this, "Failed to delete", Toast.LENGTH_SHORT).show();
                                    });
                                })
                                .setNegativeButton("No", null)
                                .show();
                    });

                } else {
                    Toast.makeText(DetailActivity.this, "Student data not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Firebase", "Failed to read data", error.toException());
                Toast.makeText(DetailActivity.this, "Error loading data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
